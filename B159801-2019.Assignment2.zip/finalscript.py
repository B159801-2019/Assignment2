#! /usr/bin/python3
import os, shutil, subprocess, sys, numpy, re
import pandas as pd

###### 1. Get Information from User: Taxon and protein ########
print("The aim of the programme is to use the NCBI protein database to get relevant biological information about a family of protein for a certain taxonomic tree\n")
#Get user to input taxon they wish to analyze
def taxonid():
	global taxon # makes the variable 'taxon' available outside of the taxonid function
	taxon = input('Enter taxon you wish to analyze:\n')
	subprocess.call("esearch -db Taxonomy -query '{}' | esummary > taxonID.txt".format(taxon), shell=True) #check taxonomy database to see if taxon exisits. Subprocess.call calls use of bash

#checks if taxonID.txt file is empty or not. If it is empty, taxon doesn't exisit. Must re-type taxon
	with open ("taxonID.txt" , "r+") as f:
		f.seek(0)
		if f.read() == "" :
			print("TaxonID has not been found in the database. Please re-type taxon.")
			taxonid()#recursion (calling function in itself)
		else : # taxonID.txt isn't empty. Extract taxon ID and rank and give user a summary
			taxonsummary=open("taxonID.txt").read()
			taxonID= re.search("<TaxId>(.*)</TaxId>", taxonsummary) #finds text inbetween <Taxid>
			taxonRank= re.search("<Rank>(.*)</Rank>", taxonsummary)
			print(f"The taxon ID for {taxon} is: {taxonID.group(1)}.\nThe rank for {taxon} is: {taxonRank.group(1)}.") #print(f"") allows variables to be called in "" when use {}

taxonid() #call function

def checkidwanted(): #User now has information about taxon. Check that they want to continue analysis.
	usercheck =input("Is this the taxon you want to continue with? Type 'yes' to continue, or 'no' to re-type a new taxon:\n")
	if usercheck == 'yes':
		print (f"Perfect. We shall continue analysis with {taxon}")
	elif usercheck == 'no': #calls previous function and current function, essentially starting script from beginning
		taxonid()
		checkidwanted()
	else:
		print("Oops, invalid option. Let's try again")	#ask same question again if user doesn't type 'yes/no'
		checkidwanted()				 	
checkidwanted() 

def protein_seqid():
	global protein_seq
	protein_seq = input(f"Enter protein sequence you wish to analyze in {taxon}:\n")
	def user_protein(): # nested function. Keeps these two questions together
		check_protein = input(f"We shall be analyzing {protein_seq} in {taxon}. Are you happy with this protein sequence?\nType 'yes' to continue and 'no' to re-type new protein sequence.\n")
		if check_protein == 'yes':
			print(f"Brilliant. We shall first find the relevant FASTA sequence(s) for {taxon} AND {protein_seq}.")
		elif check_protein == 'no':
			protein_seqid()
			user_protein()
		else:
			print("Oops, invalid option. Let's try again")
			user_protein()
		
	user_protein()
protein_seqid()

def esearch_summary():
#Ask user if that want to specify search using [PROT] and [Organism] or not
	esearch_type= input(f"Three options for database search:\n1. Search database using {protein_seq}[PROT] AND {taxon}[Organism], Type '1'\n2. Search database using {protein_seq} and {taxon}, Type '2'\n3. Search database using {protein_seq}[PROT] and {taxon}[Organism] NOT PARTIAL NOT COMPLETE, Type '3'\n")
	if esearch_type == '1':
		subprocess.call("esearch -db protein -query '{}[PROT] AND {}[Organism]' > esearchsummary.txt".format(protein_seq,taxon),shell=True)
	elif esearch_type == '2':
		subprocess.call("esearch -db protein -query '{} AND {}' > esearchsummary.txt".format(protein_seq,taxon),shell=True)
	elif esearch_type == '3':
		subprocess.call("esearch -db protein -query '{}[PROT] AND {}[Organism] NOT PARTIAL NOT COMPLETE' >esearchsummary.txt".format(protein_seq,taxon),shell=True)
	else:
		print("Oops invalid option, let's try again.")
		esearch_summary()
	
	def counts(): #counts how many fasta files that will be downloaded. Program has a maximum of 10,000. If more than 10,000 proteins to download, it will exit program. If empty, will be flagged in next function	
		esearchsummary=open("esearchsummary.txt").read()
		summary_count= re.search("<Count>(.*)</Count>", esearchsummary)
		fasta_count= int(summary_count.group(1))
	
		if fasta_count > 10000: 
			print("Unfortunately, this program will only get fasta files if there are less than 10,000.\nExitting program, restart if you would like to run it again")
			exit() #program will exit. if want to perform again, will have to restart. Do this check to prevent having to download 10,000 files

		def esearch_fetch():
# esearch on protein database for variable protein_seq and taxon.
			if esearch_type == '1':
				subprocess.call("esearch -db protein -query '{}[PROT] AND {}[Organism]'| efetch -format fasta > protein.fasta".format(protein_seq,taxon),shell=True)
			if esearch_type == '2':
				subprocess.call("esearch -db protein -query '{} AND {}' | efetch -format fasta > protein.fasta".format(protein_seq,taxon),shell=True)
			if esearch_type == '3':
				subprocess.call("esearch -db protein -query '{}[PROT] AND {}[Organism]'| efetch -format fasta > protein.fasta".format(protein_seq,taxon),shell=True)
			with open ("protein.fasta" , "r+") as f: #In case there is no FASTA files. Must reinput data from user. Invalid protein sequence (as already taxon check)
				f.seek(0)
				if f.read() == "" :
					no_fasta=input(f"No FASTA files found for {taxon} AND {protein_seq}.\nTo re-type a protein sequence, type 'protein'. Or to start from beginning, type 'start'.\n")
					if no_fasta == 'protein':
						protein_seqid()
						esearch_summary()
					elif no_fasta == 'start':
						taxonid()
						checkidwanted()
						protein_seqid()
						esearch_summary()
					
					else:
						print(f"Oops, invalid option. Let's try again")
						esearch_fetch()
		esearch_fetch()
	counts()
esearch_summary()


# Extract the number of FASTA files. Each start with '>' so string where each '>' starts

with open("protein.fasta") as file:
	fasta_count=file.read().replace("\n","").split(">")
	fasta_final=list(filter(None,fasta_count)) #First item in list was empty. This removes any empty elements in list
	print(f"There are {len(fasta_final)} FASTA sequences") #counts how many list elements there are
	fasta_number=len(fasta_final)
        
# Extract the number of different species. All species are in square brackets []. Then use non-redundant set of elements in the list 
                
with open("protein.fasta") as file2:
	species_read= file2.read()
	species_extract=re.findall("\[(.*?)\]", species_read) #find string in between []
	species_count=list(set(species_extract)) #create a non reduncant list
	print(f"For {len(species_count)} different species\n")
print("Number of fasta files for each species\n")
freq = {} #dictionary
#Count number of fasta sequences for each species and store in dictionary
for spec in species_extract:
	if (spec in freq):
		freq[spec] +=1 #more than one fasta file for a species, will add a count
	else:
		freq[spec] =1
#order dictionary from most fasta sequences from one species to least
s= [(k, freq[k]) for k in sorted(freq, key=freq.get, reverse=True)] #highest to lowest
for k, v in s:
	print(k,v)

########### 2. Determine and Plot Level of Conservation between the protein sequences ###########
# clustalo - protein alignment, --threads 40 allow parallel proccessing
subprocess.call("clustalo -i protein.fasta -o protein.align --threads 40",shell=True) #multiple protein alignment

subprocess.call("cons -sequence protein.align -outseq consensus.con",shell=True) #create consensus sequence using aligned file

with open("consensus.con") as f: #when has 'x' will not be read by blastp. Manipulate data to remove 'x' and join rest of data together
	replaced_x= f.read().replace("x","")
	sequence=" ".join(replaced_x.split())
	sequence2=sequence.replace(" ", "")
	final_seq = re.sub(">EMBOSS_001", ">EMBOSS_001\n", sequence2)
	my_outfile = open("consensus.con", "w")
	my_outfile.write(final_seq)
	my_outfile.close()

subprocess.call("makeblastdb -in protein.fasta -dbtype prot -out protein",shell=True) #make blast database using the fasta sequences downloaded from protein dtabase

subprocess.call("blastp -db protein -query consensus.con >blastoutput.out",shell=True) #run against consensus sequence made

if fasta_number >250: 
#if more than 250 fasta files, extract the most similar. I've used bitscore to determine this. the higher the bitscore the better the sequence similarity
	print(f"There are more than 250 fasta files. Extracting the 250 most similar files based on bitscore\nConservation plot from these files will then be made")

	blast_list= open("blastoutput.out").readlines()

	for con250 in blast_list:
	#if line contains the protein sequence name and doesn't start with a >.
	#This should extract protein sequence name and its bitscore and evalue. one per line.
		if con250.count(f"{protein_seq}") > 0 and con250.find(">")==-1:
			my_outfile = open("score_and_evalue.txt", "a")
			my_outfile.write(con250)
			my_outfile.close()
			
 	#bitscore ordered. therefore can just extract top 250 lines
	with open("score_and_evalue.txt") as file:
		head=[next(file) for x in range(250)] #gets top 250 by bit score
		acc_list=([i.split()[0] for i in head]) #get accession of top 250
	
	with open("protein.align") as file:
		align=file.read().split(">")
	#cross reference accession list from the 250 most similar files with the aligned files. Extract relevant alignment
	for accession in acc_list:
		for fasta_align in align:
			if re.search(accession, fasta_align): #if file contains accession number in aligned file, move to new file
				my_outfile=open("protein_final.align","a")
				my_outfile.write(f">{fasta_align}\n")
				my_outfile.close()

	with open("protein.fasta") as file:
		data=file.read().split(">")
	#same as above, but for fasta file instead of aligned file
	for accession in acc_list:
		for fasta in data:
			if re.search(accession,fasta):
				my_outfile=open("protein_final.fasta","a")
				my_outfile.write(f">{fasta}\n")
				my_outfile.close()
else:
# change name of protein.align so same name as if there were more than 250 fasta files. Can use same input for plotcon.
	os.rename("protein.align", "protein_final.align")
	os.rename("protein.fasta","protein_final.fasta")
### Plotcon ###
subprocess.call("plotcon -sequence protein_final.align -winsize 10 -graph cps",shell=True)
print(f"An output file called 'plotcon.ps' has been saved if you want to refer to it later")
#output plotcon externally via firefox
subprocess.call("firefox plotcon.ps",shell=True)

##### Scan Protein Sequences of Interests with Motifs from the PROSITE database #####

#patmatmotifs can only process one fasta file at a time

os.mkdir("Motif_Directory") #Make a new directory. This will store all the results
motifinput= open("protein_final.fasta").readlines()
for singlefasta in motifinput:
	if singlefasta.startswith(">"): #get header of fasta sequence (accession, species) and create file
		fasta_name=singlefasta.replace('>','').split()
		name=fasta_name[0]
 		#get name of accession. This will be the input for patmatmotif

		myoutfile= open(f"{name}","w")
		myoutfile.write(singlefasta)
		myoutfile.close()
	else:
		myoutfile=open(f"{name}","a") #append sequence to the file with the header
		myoutfile.write(singlefasta)
		myoutfile.close()              
		#with single fasta file created, input into patmatmotif
		subprocess.call("patmatmotifs -sequence {} -outfile {}.patmatmotifs".format(name,name),shell=True)
                
#Combine the patmatmotif output into one file
		motifout=open("motif.txt","a")
		tempfile=open(f"{name}.patmatmotifs","r")
		data2=tempfile.read()
		motifout.write(data2)
		motifout.close()
		tempfile.close()
#tidying up of files. 
		os.remove(f"{name}")
		shutil.move(f"{name}.patmatmotifs", f"Motif_Directory/{name}.patmatmotifs")

print("If you would like to see the individual fasta file results when scan against prosite database, the files have been saved to a directory called: Motif_Directory\n Else, to see summary file, see motif.txt")
                		                 
with open("motif.txt") as f: #motif.txt is combined file of all patmatmotifs input
#neaten up output
	data=f.read().replace("-","")
	#remove hashtags
	data2=re.sub('#\S+', '',data)
	#splitting with 'Sequence: ' will mean the first word of each element in the list will b$
	data3=data2.split("Sequence: ") #first word of each list will be accession number 
                                
                                
motif_dict={}
for line in data3:
	if "Motif = " in line: #extracts data with motifs only
		acc_number=line.split()
		motifid=set(re.findall(r"Motif = (.*?)\n", line)) #made non-redundant as sometimes find same motif in same fasta file. use of findall incase more than one motif per fasta file
		motifid_list = motifid
		listStr= ' AND '.join([str(elem) for elem in motifid_list]) #make a string so can go in single column when make dataframe
		motif_dict[acc_number[0]]=listStr
                                 

print(f"\nThese are the different motifs found:{set(list(motif_dict.values()))}")
#create dataframe using pandas
make_df=motif_dict
motifout=pd.DataFrame.from_dict(make_df, orient= 'index', columns={'Motifs'})
print(motifout)


####### Wildcard: Pepstat and IQ Tree ######
#summary of protein data
subprocess.call("pepstats -sequence protein_final.fasta -outfile summary.pepstats", shell=True)


with open("summary.pepstats") as file:
	data=file.read().replace("\t", " ").split("PEPSTATS of ")
	pepsum=list(filter(None,data))

#empty lists
acc_list=[]
residue_list=[]
mw_list=[]
charge_list=[]

for summary in pepsum: #extract relevant data from pepstats file
	acc= summary.split()
	acc_list.append(acc[0])
	residue= re.search(r"Residues = (.*?) \n",summary)
	residue_list.append(residue.group(1))
	mw=re.search(r"Molecular weight = (.*?)  Residues", summary)
	mw_list.append(mw.group(1))
	charge=re.search(r"Charge   = (.*?)\n", summary)
	charge_list.append(charge.group(1))

#create dataframe, indexing accession
print("A Table of Accessions and some summary data of their makeup\n")
df = pd.DataFrame.from_records({'Accession': acc_list, 'Charge': charge_list, 'Residues': residue_list, 'Molecular Weight': mw_list}, index='Accession')
print(df)

print("To see all summary protein data, open file: summary.pepstats\n")
#iqtree

print("Please be patient while producing an iqtree.")

subprocess.call("iqtree -s protein_final.align -m MFP -quiet",shell=True)

#extract graphical looking iqtree
#Will display line from MAXIMUM LIKELIHOOD TREE to Tree in newick format. Other data scary looking, only want to show nice looking data
with open("protein_final.align.iqtree") as file:
	recordlines= False
	for line in file:
		if not recordlines:
			if line.startswith('MAXIMUM LIKELIHOOD TREE'):
				recordlines = True
		elif line.startswith('Tree in newick format'):
			recordlines = False
		else:
			print(line)
		
#move files from IQTree to new directory	
os.mkdir("IQTree")
destination="./IQTree"

for files in os.listdir("."):
	if files.startswith("protein_final.align."):
		shutil.move(files,destination)
                                        
print("END OF PROGRAM. HAVE A GOOD DAY :)")
